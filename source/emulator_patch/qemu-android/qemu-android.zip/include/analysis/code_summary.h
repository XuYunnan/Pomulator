#ifndef BIN_CODE_SUMMARY
#define BIN_CODE_SUMMARY

typedef struct BinCodeSummary {
    short simpint;
    short loa;
    short sto;
    short neon;
    short vfp;
    short multi;
    short devid;
    double time;
    double energy;
} BinCodeSummary;

#endif
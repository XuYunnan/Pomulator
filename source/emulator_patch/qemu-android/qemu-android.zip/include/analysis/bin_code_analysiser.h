#ifndef BIN_CODE_ANALYSISER
#define BIN_CODE_ANALYSISER

#include <stdio.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <sched.h>



#include "elf.h"
#include "disas/bfd.h"
#include "qemu/typedefs.h"

// #include "target-arm/cpu.h"
/*
#include "config.h"
#include "cpu.h"

#include "exec/cpu-all.h"
#include "exec/memory.h"
#include "exec/ram_addr.h"
#include "exec/address-spaces.h"
*/

#include "analysis/code_summary.h"
#include "analysis/thread_summary.h"
#include "analysis/hardware_and_total.h"

extern int analysis_bin_code;
extern void * message_windows;

extern unsigned int * current_pid;
extern unsigned int * thread_number;
extern unsigned int * thread_set;

extern int system_service_pid;
extern int surfaceflinger_pid;


typedef struct pid_trace_info {
    unsigned int pid;
    unsigned int father;
    unsigned int status;

    unsigned int network_send_times;
    unsigned int network_recv_times;
    unsigned int network_data_count;

    unsigned int sdcard_sync_write_times;
    unsigned int sdcard_aio_write_times;
    unsigned int sdcard_sync_read_times;
    unsigned int sdcard_aio_read_times;
    unsigned int sdcard_read_data_count;
    unsigned int sdcard_write_data_count;

    unsigned int futex_wakeup_by;
    unsigned int futex_wait_times;
    unsigned int futex_wake_times;

    unsigned int waitqueue_wakeup_by;
    unsigned int waitqueue_wait_times;
    unsigned int waitqueue_wakeup_times;

    int padding[2];

} pid_trace_info;

typedef struct bio_info_t {
    unsigned int bio_write_time;
    unsigned int bio_read_time;
    long long bio_total_data_count;
} bio_info_t;

void initAnslysis();
void startAnalysisThread();
void stopAnalysisThread();

inline void analysis_code(BinCodeSummary summary, unsigned int pid);

extern void * get_message_window_host_addr();

#endif
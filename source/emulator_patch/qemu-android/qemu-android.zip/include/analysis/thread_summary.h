#ifndef THREAD_SUMMARY
#define THREAD_SUMMARY

typedef struct ThreadSummary {
    long long simpint;
    long long loa;
    long long sto;
    long long multi;
    long long devid;
    long long neon;
    long long vfp;
    double time;
    double energy;
} ThreadSummary;

#endif
#ifndef HARDWARE_AND_TOTAL
#define HARDWARE_AND_TOTAL

#include <stdio.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <sched.h>

typedef struct ScreenStatus {
	int R;
	int G;
	int B;

	int liangdu;
} ScreenStatus;

extern ScreenStatus * screen_status;
// extern int post_time;

extern int * R;
extern int * G;
extern int * B;
extern int * post_time;

extern int * dma_times;
extern long long * dma_data_count;

extern unsigned int * image2Ddraw_number;
extern long long * image2Ddraw_size;

extern unsigned int * drawElements_times;
extern long long * drawElements_counts;

int init_screen_info();

int dma_record(int len);

#endif
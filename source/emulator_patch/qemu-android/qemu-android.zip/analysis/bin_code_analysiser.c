#include "analysis/bin_code_analysiser.h"
#include <pthread.h>


int analysis_bin_code = 0;
unsigned int * bin_code_buffer = NULL;
pthread_t p;
void * message_windows = NULL;
void * message_windows_host_virtual = NULL;
unsigned int * current_pid = NULL;
unsigned int * thread_set = NULL;
unsigned int * thread_number = NULL;

unsigned int * thread_info_start = NULL;

bio_info_t * bio_info = NULL;

const int MAXPID = 8192;

ThreadSummary * threadInfoList;

FILE * traceFile;

int system_service_pid = -1;
int surfaceflinger_pid = -1;


// analysis per thread each 0.02s
void insn_analysis_func() {
	fprintf(stderr, "insn_analysis thread start!\n");

	traceFile = fopen("/home/xuyn/develop/emu/external/trace/trace.txt", "w");

	if(traceFile == NULL) {
		printf("Create trace file failed.\n");
		return;
	}

	ThreadSummary * lastInsnTime = (ThreadSummary *) malloc(sizeof(ThreadSummary) * MAXPID);
	memset(lastInsnTime, 0, sizeof(ThreadSummary) * MAXPID);

	char buffer[1024];
	while(1) {
		int threadnum = *thread_number;
		int i = 0;

		memset(buffer, '\0', 1024);

		int len = sprintf(buffer, "\nthreadnum = %d , hardware info and pids info : ",threadnum);
		for (i=0;i<threadnum;i++) {
			char intbuffer[10];
			int intlen = sprintf(intbuffer, "%d,", thread_set[i]);

			int j;
			for(j=0;j<intlen;j++){
				buffer[len] = intbuffer[j];
				len ++;
			}
		}
		
		buffer[len] = '\n';
		len ++;

		fwrite(buffer,sizeof(char),len,traceFile);


		char displayinfo_buffer[256];
		int displayinfo_len = sprintf(displayinfo_buffer, "Screen : %d,%d,%d,%d\n", *post_time, *R, *G, *B);
		fwrite(displayinfo_buffer,sizeof(char),displayinfo_len,traceFile);
		
		char dma_info_buffer[256];
		int dma_info_len = sprintf(dma_info_buffer, "DMA : %d,%lld\n", *dma_times, *dma_data_count);
		fwrite(dma_info_buffer, sizeof(char), dma_info_len, traceFile);

		char bio_info_buffer[256];
		int bio_info_len = sprintf(bio_info_buffer, "BIO : %d,%d,%lld\n", bio_info->bio_write_time, bio_info->bio_read_time, bio_info->bio_total_data_count);
		fwrite(bio_info_buffer, sizeof(char), bio_info_len, traceFile);

		char gpu_info_buffer[256];
		int gpu_info_len = sprintf(gpu_info_buffer, "GPU : %d, %lld; %d, %lld\n", *image2Ddraw_number, *image2Ddraw_size, *drawElements_times, *drawElements_counts);
		fwrite(gpu_info_buffer, sizeof(char), gpu_info_len, traceFile);

		if (system_service_pid > 0 && surfaceflinger_pid > 0) {
			char system_important_buffer[256];
			int system_important_buffer_len = sprintf(system_important_buffer, 
				"system_service:%lf, %lld, %lld, %lld, %lld, %lld, %lld, %lld\nsurfaceflinger:%lf, %lld, %lld, %lld, %lld, %lld, %lld, %lld\n",
				threadInfoList[system_service_pid].time,
				threadInfoList[system_service_pid].simpint,
				threadInfoList[system_service_pid].loa,
				threadInfoList[system_service_pid].sto,
				threadInfoList[system_service_pid].multi,
				threadInfoList[system_service_pid].devid,
				threadInfoList[system_service_pid].neon,
				threadInfoList[system_service_pid].vfp,

				threadInfoList[surfaceflinger_pid].time,
				threadInfoList[surfaceflinger_pid].simpint,
				threadInfoList[surfaceflinger_pid].loa,
				threadInfoList[surfaceflinger_pid].sto,
				threadInfoList[surfaceflinger_pid].multi,
				threadInfoList[surfaceflinger_pid].devid,
				threadInfoList[surfaceflinger_pid].neon,
				threadInfoList[surfaceflinger_pid].vfp
				);
			fwrite(system_important_buffer, sizeof(char), system_important_buffer_len, traceFile);
		}
		pid_trace_info * each_thread_info = (pid_trace_info *) thread_info_start;
		for(i=0;i<threadnum;i++) {
			char eachbuffer[256];
				int eachlen = sprintf(eachbuffer, 
					"%d: %d, %d; %d, %d, %d, %d, %d, %d; %d, %d, %d, %d, %d, %d; %lf, %lf, %lld, %lld, %lld, %lld, %lld, %lld, %lld\n",
				each_thread_info[i].pid, 
				each_thread_info[i].father, 
				each_thread_info[i].status, 

				each_thread_info[i].futex_wakeup_by,
				each_thread_info[i].futex_wait_times,
				each_thread_info[i].futex_wake_times,
				each_thread_info[i].waitqueue_wakeup_by,
				each_thread_info[i].waitqueue_wait_times,
				each_thread_info[i].waitqueue_wakeup_times,

				each_thread_info[i].sdcard_sync_read_times,
				each_thread_info[i].sdcard_read_data_count,
				each_thread_info[i].sdcard_sync_write_times,
				each_thread_info[i].network_send_times,
				each_thread_info[i].network_recv_times,
				each_thread_info[i].network_data_count,

				threadInfoList[thread_set[i]].time - lastInsnTime[thread_set[i]].time,
				threadInfoList[thread_set[i]].energy - lastInsnTime[thread_set[i]].energy,
				threadInfoList[thread_set[i]].simpint - lastInsnTime[thread_set[i]].simpint,
				threadInfoList[thread_set[i]].loa - lastInsnTime[thread_set[i]].loa,
				threadInfoList[thread_set[i]].sto - lastInsnTime[thread_set[i]].sto,
				threadInfoList[thread_set[i]].multi - lastInsnTime[thread_set[i]].multi,
				threadInfoList[thread_set[i]].devid - lastInsnTime[thread_set[i]].devid,		
				threadInfoList[thread_set[i]].neon - lastInsnTime[thread_set[i]].neon,
				threadInfoList[thread_set[i]].vfp - lastInsnTime[thread_set[i]].vfp
				);

			fwrite(eachbuffer,sizeof(char),eachlen,traceFile);
			lastInsnTime[thread_set[i]].time = threadInfoList[thread_set[i]].time;
			threadInfoList[thread_set[i]].energy = lastInsnTime[thread_set[i]].energy,
			lastInsnTime[thread_set[i]].simpint = threadInfoList[thread_set[i]].simpint;
			lastInsnTime[thread_set[i]].loa = threadInfoList[thread_set[i]].loa;
			lastInsnTime[thread_set[i]].sto = threadInfoList[thread_set[i]].sto;
			lastInsnTime[thread_set[i]].multi = threadInfoList[thread_set[i]].multi;
			lastInsnTime[thread_set[i]].devid = threadInfoList[thread_set[i]].devid;			
			lastInsnTime[thread_set[i]].neon = threadInfoList[thread_set[i]].neon;
			lastInsnTime[thread_set[i]].vfp = threadInfoList[thread_set[i]].vfp;
		}

		fflush(traceFile);
		usleep(20000);
	}
}


inline void analysis_code(BinCodeSummary summary, unsigned int pid){
	if (pid >= MAXPID) {
		fprintf(stderr, "PID is bigger than MAXPID.\n");
		return;
	}

	threadInfoList[pid].simpint += summary.simpint;
	threadInfoList[pid].loa += summary.loa;
	threadInfoList[pid].sto += summary.sto;
	threadInfoList[pid].multi += summary.multi;
	threadInfoList[pid].devid += summary.devid;
	threadInfoList[pid].neon += summary.neon;
	threadInfoList[pid].vfp += summary.vfp;
	threadInfoList[pid].time += summary.time;
	threadInfoList[pid].energy += summary.energy;
}

void startAnalysisThread() {

	fprintf(stderr, "start analysis thread\n");

	memset(threadInfoList, 0 , MAXPID * sizeof(ThreadSummary));

	message_windows_host_virtual = get_message_window_host_addr();
	if (message_windows_host_virtual) {
		current_pid = (unsigned int *) (message_windows_host_virtual + 1024);
		thread_number = (unsigned int *) (message_windows_host_virtual + 1028);
		thread_set = (unsigned int *) (message_windows_host_virtual + 1032);
		bio_info = (bio_info_t *) (message_windows_host_virtual + 2048);
		thread_info_start = (unsigned int *) (message_windows_host_virtual + 4096);

		printf("%s\n", (char *)message_windows_host_virtual);

		int pppid = *current_pid;
		printf("current pid = %d\n", pppid);
		printf("current_pid = %p, thread_set  = %p.\n", current_pid, thread_set);
	}

	analysis_bin_code = 1;

	pthread_cancel(p);

	int ret = pthread_create(&p, NULL, (void *)insn_analysis_func, NULL);
	if (ret != 0) {
		fprintf(stderr, "create analysis thread failed.\n");
	}
}

void stopAnalysisThread() {
	analysis_bin_code = 0;
	fprintf(stderr, "stop analysis thread\n");

	pthread_cancel(p);

	int i = 0;
	/*
	fprintf(stderr, "======================================================================\n");
	fprintf(stderr, "======================================================================\n");
	fprintf(stderr, "======================================================================\n");
	fprintf(stderr, 
		"MAXPID is %d, simpint = %lld, loa = %lld, sto = %lld, multi = %lld, devid = %lld, neon = %lld, vfp  = %lld, time = %lf, energy = %lf\n"
		, maxpid, threadInfoList[maxpid].simpint, threadInfoList[maxpid].loa, threadInfoList[maxpid].sto, threadInfoList[maxpid].multi, threadInfoList[maxpid].devid
		, threadInfoList[maxpid].neon, threadInfoList[maxpid].vfp, threadInfoList[maxpid].time, threadInfoList[maxpid].energy);
	fprintf(stderr, "======================================================================\n");
	fprintf(stderr, "======================================================================\n");
	fprintf(stderr, "======================================================================\n");
	*/
	FILE * result = fopen("/tmp/xuyn_analysis.txt", "w");
	if (result) {
		for (i=0;i<MAXPID;i++) {
			fprintf(result, "%d : simpint = %lld, loa = %lld, sto = %lld, multi = %lld, devid = %lld, neon = %lld, vfp  = %lld, time = %lf, energy = %lf\n"
			, i , threadInfoList[i].simpint, threadInfoList[i].loa, threadInfoList[i].sto, threadInfoList[i].multi, threadInfoList[i].devid
			, threadInfoList[i].neon, threadInfoList[i].vfp, threadInfoList[i].time, threadInfoList[i].energy);
		}
		fclose(result);
	}
}

void initAnslysis() {
	printf("pid_trace_info size = %d\n", (int) sizeof(pid_trace_info));
	threadInfoList = (ThreadSummary *) malloc(sizeof(ThreadSummary) * 8192);
	init_screen_info();
}
#include "analysis/hardware_and_total.h"

#include <stdio.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>
#include <pthread.h>
#include <mqueue.h>
#include <sys/signal.h>


int * message_share_h = NULL;

ScreenStatus * screen_status = NULL;
int * post_time = NULL;
int * R = NULL;
int * G = NULL;
int * B = NULL;

int * dma_times = NULL;
long long * dma_data_count = NULL;

unsigned int * image2Ddraw_number = NULL;
long long * image2Ddraw_size = NULL;

unsigned int * drawElements_times = NULL;
long long * drawElements_counts = NULL;

void hardware_info_record () {

    printf("Hardware info init.\n");
    message_share_h = (int *) malloc(1024);

    memset(message_share_h, 0, 1024);

    message_share_h[0] = 1234;

    FILE* f = fopen("/tmp/hardware_info_addr.txt", "w+");

    fprintf(f, "%p", message_share_h);

    fclose(f);

    R = message_share_h + 1;
    G = message_share_h + 2;
    B = message_share_h + 3;
    post_time = message_share_h + 4;

    dma_times = message_share_h + 7;
    dma_data_count = (long long *) (message_share_h + 8);

    image2Ddraw_number = (unsigned int *) (message_share_h + 16);
    image2Ddraw_size = (long long *) (message_share_h + 18);
    drawElements_times = (unsigned int *) (message_share_h + 24);
    drawElements_counts = (long long *) (message_share_h + 32);
}


int init_screen_info() {
    hardware_info_record();
	return 0;
}


int dma_record(int len) {
    if (!message_share_h) return -1;

    *dma_times = *dma_times + 1;
    *dma_data_count = *dma_data_count + (long long) len;

    return 0;
}
#ifndef TARGET_CODE_BUFFER
#define TARGET_CODE_BUFFER
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>

// #if defined(TARGET_ARM)

// target code buffer size  = 256M
const static int TargetCodeBufferSize = 1 << 28;

typedef struct target_code_buffer {
	unsigned int * targetCodeBuffer;
	int current;
} target_code_buffer;

int initTargetCodeBuffer(target_code_buffer * t);

inline unsigned int * findSpace(target_code_buffer * t, int size);

// #endif
#endif
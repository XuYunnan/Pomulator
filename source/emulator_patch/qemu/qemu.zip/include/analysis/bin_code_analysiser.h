#ifndef BIN_CODE_ANALYSISER
#define BIN_CODE_ANALYSISER

#include <stdio.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <sched.h>

#include "analysis/memory_sharer.h"
#include "analysis/per_thread_analysis.h"

void initAnslysis(unsigned int * target_code);
void startAnalysisThread();
void stopAnalysisThread();

#endif
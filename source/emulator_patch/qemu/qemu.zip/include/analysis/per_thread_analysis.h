#ifndef PER_THREAD_ANALYSIS_H
#define PER_THREAD_ANALYSIS_H

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>

typedef struct insn_counter {
	int totCount;
	int intCount;
	int floutCount;
	int memCount;
} insn_counter;

typedef struct per_thread_info {

	int threadId;
	insn_counter insnCounter;

} per_thread_info;




per_thread_info * thread_info_array;


const static int MAX_THREAD_NUM = 5000;
void init_thread_info_collector();
inline int add_insn_data(int threadId, unsigned int insn);

#endif
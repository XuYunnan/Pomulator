#ifndef NETWORK_STATE_H
#define NETWORK_STATE_H


typedef struct network_data {
	double timestamp;
	unsigned short size;
	char up;
} network_data;

static const int NETWORK_BUFFER_SIZE = 256;

typedef struct network_data_recorder {

	network_data * dataList;
	int head;
	int tail;
	int size;
	unsigned int totData;
} network_data_recorder;

typedef struct power_state {
	int stateId;
	struct power_state *  (* next_state) (double packetPerSecond, double dataPerSecond);
} power_state;

#endif
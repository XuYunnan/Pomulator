#ifndef ANALYSIS_MEMORY_SHARER
#define ANALYSIS_MEMORY_SHARER
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include "exec/cpu-all.h"
#include "analysis/analysis_queue.h"
#include "analysis/target_code_buffer.h"
#include "tcg/tcg.h"
#if defined(TARGET_ARM)
#include "target-arm/cpu.h"
#endif

const static int insnBufferSize = 2 << 28;

analysis_queue insnBuffer;

bool analysis_target;

int init_memory_sharer_objs();

#if defined(TARGET_ARM)
inline int arm_ib_send_message(int start, int size, int threadId);
#endif

#endif

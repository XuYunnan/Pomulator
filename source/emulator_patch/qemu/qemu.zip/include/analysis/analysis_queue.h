#ifndef ANALYSIS_QUEUE_H
#define ANALYSIS_QUEUE_H

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>

typedef struct ToBeSentBuffer {
	int start;
	int len;
	int threadId;
}ToBeSentBuffer;

typedef struct analysis_queue {
	int capacity; // must be 2 ^ n
	int head;
	int tail;
	int size;
	ToBeSentBuffer * buffer;
} analysis_queue;

// init a queue
int queue_init(analysis_queue * q, int capacity);

// put x into queue
inline int queue_put(analysis_queue * q, ToBeSentBuffer x);

// get x from queue
inline int queue_get(analysis_queue * q, ToBeSentBuffer * x);

#endif
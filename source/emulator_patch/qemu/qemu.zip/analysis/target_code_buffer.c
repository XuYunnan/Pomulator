#include "analysis/target_code_buffer.h"

// #if defined(TARGET_ARM)

int initTargetCodeBuffer(target_code_buffer * t) {
	if (!t) return -1;
	t -> targetCodeBuffer = malloc(TargetCodeBufferSize);
	t -> current = 0;
	return 0;
}

inline unsigned int * findSpace(target_code_buffer * t, int size) {
	if (TargetCodeBufferSize - t->current >= size) {
		int temp = t->current;
		t->current += size;
		return t->targetCodeBuffer + temp;
	} else {
		t->current = size;

		fprintf(stderr, "loop");

		return t -> targetCodeBuffer;
	}
}

// #endif
#include "analysis/user_control.h"

void control_thread () {
	fprintf(stderr, "User control thread started.\n");
	char buf[1024];
	mqd_t mqID;

	// pthread_t tid = pthread_self();
	sigset_t mask;
	sigfillset(&mask);
	pthread_sigmask(SIG_SETMASK, &mask, NULL); 

	while(1) {
    	mqID = mq_open("/qemu_user_control", O_RDWR | O_CREAT, 0666, NULL);
    	if (mqID < 0)  
    	{  
        	if (errno == EEXIST)
        	{  
            	mq_unlink("/qemu_user_control");  
            	mqID = mq_open("/qemu_user_control", O_RDWR | O_CREAT, 0666, NULL);  
        	}  
        	else  
        	{
            	fprintf(stderr, "Create message queue failed. error info is %s.\n", strerror(errno));
            	return ;
        	}
    	}

    	struct mq_attr mqAttr;  
    	mq_getattr(mqID, &mqAttr);  

        if (mq_receive(mqID, buf, mqAttr.mq_msgsize, NULL) < 0)  
        {  
        	fprintf(stderr, "Receive message failed. error info is %s.\n",strerror(errno) );
        	mq_close(mqID);

            continue;
        }

        if (buf[0] == '0') {
        	fprintf(stderr, "Receive message stop thread.\n");
			stopAnalysisThread();
        } else if (buf[0] == '1') {
        	fprintf(stderr, "Receive message start thread.\n");
        	startAnalysisThread();
        }
	}
    exit(0);
}

int init_user_control(){

	pthread_t p;
	int ret = pthread_create(&p, NULL, (void *)control_thread, NULL);
	if (ret != 0) {
		fprintf(stderr, "create user control thread failed.\n");
		return -1;
	}

	return 0;
}
#include "analysis/memory_sharer.h"
int init_memory_sharer_objs() {
    return queue_init(&insnBuffer, insnBufferSize);
}

#if defined(TARGET_ARM)
inline int arm_ib_send_message(int start, int size, int threadId) {
    if (!analysis_target) return 0;
    
    ToBeSentBuffer t;
    t.start = start;
    t.len = size;
    t.threadId = threadId;
	return queue_put(&insnBuffer,t);
}
#endif
#include <stdio.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <mqueue.h>

int main(int argc,char **argv) {
	
	char sendline[20];
	
    mqd_t mqID;  
    mqID = mq_open("/qemu_user_control", O_RDWR, 0666, NULL);

    int i = 0;
	while (1) {
		fgets(sendline,1024,stdin);
		mq_send(mqID, sendline, sizeof(sendline), i);
		i ++;
	}
}
#include "analysis/per_thread_analysis.h"

void init_thread_info_collector() {

	thread_info_array = (per_thread_info *) malloc (MAX_THREAD_NUM * sizeof(per_thread_info));
	int i=0;
	for (i=0;i<MAX_THREAD_NUM;i++) {
		thread_info_array[i].threadId = i;
		thread_info_array[i].insnCounter.totCount = 0;
		thread_info_array[i].insnCounter.intCount = 0;
		thread_info_array[i].insnCounter.floutCount = 0;
		thread_info_array[i].insnCounter.memCount = 0;
	}
}

inline int add_insn_data(int threadId, unsigned int insn) {

	thread_info_array[threadId].insnCounter.totCount ++;
	return 0;
}
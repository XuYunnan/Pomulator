#include "analysis/analysis_queue.h"

int queue_init(analysis_queue * q, int capacity) {
	if (capacity & (capacity - 1)) {
		fprintf(stderr,"capacity must be power of 2\n");
		return -1;
	}
	q->capacity = capacity - 1;
	q->head = 0;
	q->tail = 0;
	q->buffer = (ToBeSentBuffer *) malloc(sizeof(ToBeSentBuffer) * capacity);
	return 0;
}

// put x into queue
inline int queue_put(analysis_queue * q, ToBeSentBuffer x) {
	if (q->tail == q->head - 1 || (q->tail ==  q->capacity - 1 && q->head == 0)) {
		fprintf(stderr, "The queue is full.\n");
		return -1;
	}
	q->buffer[q->tail] = x;
	q->tail ++;
	q->tail &= q->capacity;
	return 0;
}

// get x from queue
inline int queue_get(analysis_queue * q, ToBeSentBuffer * x) {
	if (q->tail == q->head) {
		fprintf(stderr, "The queue is empty.\n");
		return -1;
	}

	*x = q->buffer[q->head];
	q->head ++;
	q->head &= q->capacity;
	return 0;
}
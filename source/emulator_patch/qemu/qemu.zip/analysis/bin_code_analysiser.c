#include "analysis/bin_code_analysiser.h"

#include <pthread.h>

unsigned int * bin_code_buffer;
pthread_t p;

void insn_analysis_func() {
	fprintf(stderr, "insn_analysis thread start!\n");
	while (1) {
		ToBeSentBuffer t;
		int ret = queue_get(&insnBuffer, &t);
		if (ret != 0) {
			if(analysis_target){
				usleep(1 << 20);
				continue;
			}
			fprintf(stderr, "insn_analysis thread finished!\n");
			return ;
		}
		int start = t.start;
		int len = t.len;
		int threadId = t.threadId;

		
		// fprintf(stderr, "\n%d, %d, %d:\n", start, len, threadId);
		
		int i;
		for (i = 0; i< len;i ++) {
			// fprintf(stderr, "%d,", bin_code_buffer[start + i]);
			add_insn_data(threadId, bin_code_buffer[start + i]);
		}

	}
}

void startAnalysisThread() {
	fprintf(stderr, "start analysis thread\n");
	analysis_target = true;
	pthread_cancel(p);
	int ret = pthread_create(&p, NULL, (void *)insn_analysis_func, NULL);
	if (ret != 0) {
		fprintf(stderr, "create analysis thread failed.\n");
	}
}

void stopAnalysisThread() {
	fprintf(stderr, "stop analysis thread\n");
	analysis_target = false;
}

void initAnslysis(unsigned int * target_code) {
	analysis_target = false;
	if (target_code) {
		bin_code_buffer = target_code;
	}

	init_thread_info_collector();
}


#include "android/base/message_sender.h"

#include <stdio.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <linux/fb.h>
#include <sys/ioctl.h>
#include <mqueue.h>


void framebuffer_post(int R, int G, int B) {
	int * hardware_info_wind;
    FILE *f = fopen("/tmp/hardware_info_addr.txt", "r");
    fscanf(f, "%p", &hardware_info_wind);
    fclose(f);
	if (hardware_info_wind) {
		hardware_info_wind[1] = R;
		hardware_info_wind[2] = G;
		hardware_info_wind[3] = B;
		hardware_info_wind[4] ++ ;
	} else {
		printf("hardware_info_wind = null\n");
	}
}
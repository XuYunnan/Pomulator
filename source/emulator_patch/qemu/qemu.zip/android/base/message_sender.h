#ifndef MESSAGE_SENDER_H
#define MESSAGE_SENDER_H


void framebuffer_post(int R, int G, int B);

#endif
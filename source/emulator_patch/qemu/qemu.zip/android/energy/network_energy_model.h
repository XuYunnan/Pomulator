#pragma once

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <time.h>
#include <pthread.h>
#include <sys/time.h>

typedef struct network_data {
	struct timeval timestamp;
	unsigned short size;
	char up;
} network_data;

static const int NETWORK_BUFFER_SIZE = 256;

typedef struct network_data_recorder {

	network_data * dataList;
	int head;
	int tail;
	int size;
	unsigned int totData;
} network_data_recorder;

typedef struct power_state {
	int stateId;
	struct power_state *  (* next_state) (double packetPerSecond, double dataPerSecond);
} power_state;

static const unsigned short SOCKET_CREATE = 180;
static const unsigned short SOCKET_HEAD = 50;
static const unsigned short SOCKET_CLOSE = 200;

void init_network_data_recorder(network_data_recorder * recorder);

void load_network_energy_model_from_config(const char * filename);

void start_network_energy_analysis_thread();

int addSendedData(unsigned short size, int up);

int updateTimer(struct timeval t);

void init_network_energy_analysiser();
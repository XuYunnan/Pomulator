#include "network_energy_model.h"

network_data_recorder recorder;
pthread_t network_energy_thread;
power_state * network_state;
power_state * current_network_state;

void init_network_data_recorder(network_data_recorder * r) {
	r->dataList = (network_data *) malloc (NETWORK_BUFFER_SIZE * sizeof(network_data));
	r->head = 0;
	r->tail = 0;
	r->size = 0;
	r->totData = 0;
}

void load_network_energy_model_from_config(const char * filename) {

	network_state = (power_state *) malloc (sizeof(power_state) * 4);

	network_state[0].stateId = 0;

	network_state[1].stateId = 1;

	network_state[2].stateId = 2;
}

void * network_energy_analysis_thread (void *arg) {
	
	// clock_t begin, end;
	
	struct timeval begin;
	struct timeval end;

	double cost;
	gettimeofday(&begin,NULL);

	int last_totData = recorder.totData;

	while(1) {

		usleep(1000000);

		gettimeofday(&end,NULL);

		cost = 1000000*(end.tv_sec-begin.tv_sec)+end.tv_usec-begin.tv_usec;
		cost /= 1000000;

		double packetPerSecond = recorder.size / cost; // packet per second
		double dataPerSecond =  recorder.totData - last_totData;

		// current_network_state = current_network_state->next_state(packetPerSecond, dataPerSecond);
		fprintf(stderr, "cost = %lf, packet rate = %lf, data rate = %lf \n",cost, packetPerSecond,  dataPerSecond);
		last_totData = recorder.totData;
		begin = end;
		updateTimer(end);
	}

	return NULL;
}

void start_network_energy_analysis_thread() {
	int ret = pthread_create(&network_energy_thread, NULL, network_energy_analysis_thread, NULL);
	if (ret != 0) {
		fprintf(stderr, "create analysis thread failed.\n");
		return ;
	}
	fprintf(stderr, "network energy analysis thread started.\n");
}

int addSendedData(unsigned short dataLen, int up) {
	
	recorder.size ++;

	gettimeofday(&(recorder.dataList[recorder.tail].timestamp),NULL);
	recorder.dataList[recorder.tail].size = dataLen;
	recorder.dataList[recorder.tail].up = (char) up;
	recorder.totData += (unsigned int) dataLen;

	recorder.tail ++;

	if (recorder.tail == NETWORK_BUFFER_SIZE) recorder.tail = 0;

	if (recorder.tail == recorder.head) {
		fprintf(stderr, "network buffer is full. recorder.tail = %d\n", recorder.tail);
		return -1;
	}
	return 0;
}

int updateTimer(struct timeval time) {

	while(recorder.size) {

		if ( recorder.dataList[recorder.head].timestamp.tv_sec < time.tv_sec) {
			recorder.size --;
			recorder.head ++;
			if(recorder.head == NETWORK_BUFFER_SIZE) recorder.head = 0;

		} else if (recorder.dataList[recorder.head].timestamp.tv_sec == time.tv_sec && 
				recorder.dataList[recorder.head].timestamp.tv_usec < time.tv_usec
			) {
			recorder.size --;
			recorder.head ++;
			if(recorder.head == NETWORK_BUFFER_SIZE) recorder.head = 0;

		} else {
			break;
		}
	}

	return 0;
}

void init_network_energy_analysiser() {
/*
	init_network_data_recorder(&recorder);

	load_network_energy_model_from_config("");

	current_network_state = current_network_state;

	start_network_energy_analysis_thread();
*/
}
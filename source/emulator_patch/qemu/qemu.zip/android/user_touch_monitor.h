#pragma once

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <time.h>
#include <pthread.h>
#include <sys/time.h>

void init_user_touch_recorder();
void screen_post();
void user_touch_screen(int type, int x, int y);



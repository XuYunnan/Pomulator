#include "user_touch_monitor.h"

pthread_t user_touch_thread;

struct timeval touch_begin;
struct timeval touch_end;

struct timeval fbpost_begin;
struct timeval fbpost_end;

bool loading;

void * screen_monitor_thread (void *arg) {

	while(1) {
		fprintf(stderr, "screen_monitor_thread check");
		usleep(500000);
	}

	return NULL;
}

void user_touch_screen(int type, int x, int y) {
	fprintf(stderr, "user_touch_screen");
}

void screen_post() {
	fprintf(stderr, "screen_post");
}

void init_user_touch_recorder() {
	int ret = pthread_create(&user_touch_thread, NULL, screen_monitor_thread, NULL);
	if (ret != 0) {
		fprintf(stderr, "create user touch monitor thread failed.\n");
		return ;
	}
	fprintf(stderr, "user touch monitor thread started.\n");

	loading = false;
}
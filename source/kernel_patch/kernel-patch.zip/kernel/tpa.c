#include <linux/tpa.h>
#include <linux/init.h>
#include <linux/debugfs.h> 
#include <linux/fs.h> 
#include <linux/kernel.h>
#include <linux/errno.h>
#include <linux/io.h>
#include <linux/slab.h>
#include <linux/gfp.h>
#include <linux/mm.h>
#include <linux/mm_types.h>
#include <asm/uaccess.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>

static struct dentry *tpa_debugfs_dir_entry_root;

unsigned int testing_app_uid = 0xffffffff;
unsigned int zygote_pid = 0xffffffff;
unsigned int surfaceflinger_pid = 0xffffffff;
unsigned int servicemanager_pid = 0xffffffff;

void * message_windows = NULL;
unsigned int * pid_message = NULL;
bio_info_t * bio_info = NULL;

int thread_number = 0;
pid_trace_info * thread_trace_info_addr = NULL;

static const struct file_operations info_op = {
	.read           = seq_read,
	.write          = seq_write,
	.llseek         = seq_lseek,
	.release        = single_release,
};

int pidPosArray[8192];

struct file* file_open(const char* path, int flags, int rights) {
    struct file* filp = NULL;
    mm_segment_t oldfs;
    int err = 0;

    oldfs = get_fs();
    set_fs(get_ds());
    filp = filp_open(path, flags, rights);
    set_fs(oldfs);
    if(IS_ERR(filp)) {
        err = PTR_ERR(filp);
        return NULL;
    }
    return filp;
}

int file_write(struct file* file, unsigned long long offset, unsigned char* data, unsigned int size) {
    mm_segment_t oldfs;
    int ret;

    oldfs = get_fs();
    set_fs(get_ds());

    ret = vfs_write(file, data, size, &offset);

    set_fs(oldfs);
    return ret;
}

void file_close(struct file* file) {
    filp_close(file, NULL);
}

int __init tpa_analysiser_start(void) {
	tpa_debugfs_dir_entry_root = debugfs_create_dir("tpa", NULL);
	if (tpa_debugfs_dir_entry_root) {
		debugfs_create_u32("test_app_uid",
				0644,
				tpa_debugfs_dir_entry_root,
				&testing_app_uid);

		debugfs_create_u32("zygote_pid",
				0644,
				tpa_debugfs_dir_entry_root,
				&zygote_pid);
		debugfs_create_u32("surfaceflinger_pid",
				0644,
				tpa_debugfs_dir_entry_root,
				&surfaceflinger_pid);
		debugfs_create_u32("servicemanager_pid",
				0644,
				tpa_debugfs_dir_entry_root,
				&servicemanager_pid);
	}

	int i;
	for(i=0;i<8192;i++) pidPosArray[i] = -1;

	message_window_init();
	return 0;
}
device_initcall(tpa_analysiser_start);


void message_window_init (void) {
	phys_addr_t phy_addr;
	const int size_mi = 6;
	unsigned int size_real = 2 << size_mi;
	
	printk("message_windows is allocing a page, page size is %d.\n", PAGE_SIZE);
	printk("pid_trace_info size = %d\n", (int) sizeof(pid_trace_info));


	struct page * message_page =  alloc_pages(GFP_KERNEL, size_mi);
	message_windows = page_address(message_page);

	unsigned int * clearer = (unsigned int *) message_windows;
	unsigned int clearerMax = size_real * PAGE_SIZE / 4;
	int k = 0;
	for (k = 0; k<clearerMax; k ++) clearer[k] = 0;

	phy_addr = page_to_phys(message_page);
	pid_message =  message_windows + 1024;
	thread_trace_info_addr = (pid_trace_info *) (message_windows + 4096);
	bio_info = (bio_info_t *) (message_windows + 2048);
	*(pid_message) = 0xffffffff;
	*(pid_message + 1) = 0;
	printk("message_windows is %p, phy_addr = %p\n", message_windows, phy_addr);

	char * ppp = (char *) message_windows;
	
	int i = 0;
	for (;i<26;i++) {
		ppp[i] = 'a' + i;
	}


	char buffer[30];

	for (; i<30;i++) {
		buffer[i] = '\0';
	}

	sprintf(buffer, "%p, %d", (void *)phy_addr,  (int) size_real * PAGE_SIZE);
}

void setCurrentPid(unsigned int pid) {
	if (pid_message)
		*pid_message= pid;
}


void addNewThread(unsigned int father_pid, unsigned int son_pid) {

	if (!pidPosArray || son_pid > 8191 || son_pid < 0 || pidPosArray[son_pid] >= 0) return ;

	analysis_pid * ana = (analysis_pid *)(message_windows + 1032);
	unsigned int * thread_number_addr = (unsigned int *) (message_windows + 1028);
	ana[thread_number].pid = son_pid;

	thread_trace_info_addr[thread_number].pid = son_pid;
	thread_trace_info_addr[thread_number].father = father_pid;

	pidPosArray[son_pid] = thread_number;

	thread_number ++;
	*thread_number_addr = thread_number;
}

int pidToPos(unsigned int pid) {
	if (pid > 8191) return -1;
	return pidPosArray[pid];
}

void setThreadStatus(unsigned int pid, int status) {
	if (thread_trace_info_addr) {
		int pos = pidToPos(pid);
		if (pos == -1) return;
		thread_trace_info_addr[pos].status = status;
	}
}

void setThreadWakeUp(unsigned int pid, unsigned int wakeupby) {
	if (thread_trace_info_addr) {
		int pos = pidToPos(pid);
		if (pos != -1) {
			thread_trace_info_addr[pos].waitqueue_wakeup_by = wakeupby;
		}

		int waker_pos = pidToPos(wakeupby);
		if (waker_pos != -1) {
			thread_trace_info_addr[waker_pos].waitqueue_wakeup_times ++;
		}
	}
}

void setThreadWait(unsigned int pid) {
	if (thread_trace_info_addr) {
		int pos = pidToPos(pid);
		if (pos != -1) {
			thread_trace_info_addr[pos].waitqueue_wait_times ++;
		}
	}
}

void setThreadRead(unsigned int pid, int dataCount, int sync) {
	if (thread_trace_info_addr) {
		int pos = pidToPos(pid);
		if (pos == -1) return;
		if (sync){
			thread_trace_info_addr[pos].sdcard_sync_read_times ++;
			thread_trace_info_addr[pos].sdcard_read_data_count += dataCount;
		}
		else{
			thread_trace_info_addr[pos].sdcard_aio_read_times ++;
			thread_trace_info_addr[pos].sdcard_read_data_count += dataCount;
		}

	}
}

void setThreadWrite(unsigned int pid, int dataCount, int sync) {
	if (thread_trace_info_addr) {
		int pos = pidToPos(pid);
		if (pos == -1) return;
		if (sync) {
			thread_trace_info_addr[pos].sdcard_sync_write_times ++;
			thread_trace_info_addr[pos].sdcard_write_data_count += dataCount;
		}
		else{
			thread_trace_info_addr[pos].sdcard_aio_write_times ++;
			thread_trace_info_addr[pos].sdcard_write_data_count += dataCount;
		}
	}
}

// iotype 0 : read, 1: write, 2 : read no block , 3: write no block
void setThreadNetwork(int len, int networkType, int iotype) {
	if(!pid_message) return ;
	int pid = *pid_message;
	int pos = pidToPos(pid);
	if (pos == -1) return;

	if(networkType == 0) {
	// udp
		if (!len || len < 0 ) return ;

		/*
		if (iotype & 1)
			thread_trace_info_addr[pos].network_send_times ++;
		else
			thread_trace_info_addr[pos].network_recv_times ++;
		*/

		thread_trace_info_addr[pos].network_data_count += len;

	} else if (networkType == 1) {
	// tcp
		if (!len || len < 0 ) return ;
		
		/*
		if (iotype & 1)
			thread_trace_info_addr[pos].network_send_times ++;
		else
			thread_trace_info_addr[pos].network_recv_times ++;
		*/
		
		thread_trace_info_addr[pos].network_data_count += len;

	} else if (networkType == 2) {
	// raw

	}
}

void setBIOWriteData(int len) {
	if (bio_info) {
		bio_info->bio_write_time ++;
		bio_info->bio_total_data_count += (long long) len;
	}
}

void setBIOReadData(int len) {
	if (bio_info) {
		bio_info->bio_read_time ++;
		bio_info->bio_total_data_count += (long long) len;
	}
}

void setFutexWakeUp(unsigned int waker, unsigned int waiter) {

	if (! thread_trace_info_addr) return ;

	int waker_pos = pidToPos(waker);
	int waiter_pos = pidToPos(waiter);

	if (waker_pos != -1) {
		thread_trace_info_addr[waker_pos].futex_wake_times ++;
	}

	if (waiter_pos != -1) {
		thread_trace_info_addr[waiter_pos].futex_wakeup_by = waker;
	}
}

void setFutexWait(unsigned int waiter) {

	if (! thread_trace_info_addr) return ;

	int waiter_pos = pidToPos(waiter);

	if (waiter_pos != -1) {
		thread_trace_info_addr[waiter_pos].futex_wait_times ++;
	}
}

void ThreadNetworkRead(int pid) {
	if (! thread_trace_info_addr) return ;
	if (!pid_message) return;
	int pos = pidToPos(pid);
	if (pos == -1) return;
	thread_trace_info_addr[pos].network_recv_times ++;
}

void ThreadNetworkWrite(int pid) {
	if (! thread_trace_info_addr) return ;
	if (!pid_message) return;
	int pos = pidToPos(pid);
	if (pos == -1) return;
	thread_trace_info_addr[pos].network_send_times ++;
}
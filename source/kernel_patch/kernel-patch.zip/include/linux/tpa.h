#ifndef __LINUX_THREAD_PERFORMANCE_ANALYSISER_H
#define __LINUX_THREAD_PERFORMANCE_ANALYSISER_H

#include <linux/proc_fs.h>
#include <linux/fs.h>

typedef struct analysis_pid {
	unsigned int pid;
} analysis_pid;


typedef struct pid_trace_info {
	unsigned int pid;
	unsigned int father;
	unsigned int status;
	
	unsigned int network_send_times;
	unsigned int network_recv_times;
	unsigned int network_data_count;
	
	unsigned int sdcard_sync_write_times;
	unsigned int sdcard_aio_write_times;
	unsigned int sdcard_sync_read_times;
	unsigned int sdcard_aio_read_times;
	unsigned int sdcard_read_data_count;
	unsigned int sdcard_write_data_count;

	
	unsigned int futex_wakeup_by;
	unsigned int futex_wait_times;
	unsigned int futex_wake_times;

	unsigned int waitqueue_wakeup_by;
	unsigned int waitqueue_wait_times;
	unsigned int waitqueue_wakeup_times;

	int padding[2];
} pid_trace_info;


typedef struct bio_info_t {
	unsigned int bio_write_time;
	unsigned int bio_read_time;
	long long bio_total_data_count;
} bio_info_t;

extern unsigned int testing_app_uid;
extern void * message_windows;
extern unsigned int * pid_message; 
extern unsigned int zygote_pid;
extern unsigned int surfaceflinger_pid;
extern unsigned int servicemanager_pid;
extern int thread_number;
extern pid_trace_info * thread_trace_info_addr;

int __init tpa_analysiser_start(void);

void setCurrentPid(unsigned int pid);

void message_window_init (void);

void addNewThread(unsigned int father_pid, unsigned int son_pid);

int pidToPos(unsigned int pid);

void setThreadStatus(unsigned int pid, int status);

void setThreadWakeUp(unsigned int pid, unsigned int wakeupby);

void setThreadWait(unsigned int pid);

void setFutexWakeUp(unsigned int waker, unsigned int waiter);

void setFutexWait(unsigned int waiter);

void setThreadRead(unsigned int pid, int dataCount, int sync);

void setThreadWrite(unsigned int pid, int dataCount, int sync);

void setThreadNetwork(int len, int networkType, int iotype);

void ThreadNetworkRead(int pid);

void ThreadNetworkWrite(int pid);

void setBIOWriteData(int len);

void setBIOReadData(int len);
#endif
